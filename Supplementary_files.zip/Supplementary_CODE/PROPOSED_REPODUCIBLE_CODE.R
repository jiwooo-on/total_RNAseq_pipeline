# Title : Unlocking the Potential of Low Quality Total RNA-seq Data: A Stepwise Mapping Approach for Improved Quantitative Analyses
# Authors : Jiwoon Lee and JungSoo Gim* (This script was written by Jiwoon Lee ! (jiun.t.ger@gmail.com))
# 

## READ MAPPING (RUNNING IN LINUX-LIKE ENVIRONMENTS) ## 
 # TOOL : STAR (version : 2.7.7a) 
 # REFERENCE GENOME : GENCODE GRCH.38 (Release version 38)

  ### INDEXING for PROPOSED mapping 
    # fasta file : Genome sequence(GRCh38.p13) / Regions : ALL 
    # GTF file : Comprehensive gene annotation /  Regions : ALL 
    # $ STAR --runMode genomeGenerate --genomeDir /out/dir/ALL_index/ --genomeFastaFiles GRCh38.p13.genome.fa --sjdbGTFfile gencode.v38.chr_patch_hapl_scaff.annotation.gtf

  ###  PROPOSED method entails additional mapping with adjusted options
   # 1st mapping (Dedault options)  
    # $ STAR --genomeDir /out/dir/ALL_index/ --readFilesIn Sequenced_s1_R1.fastq.gz Sequenced_s1_R2.fastq.gz  --quantMode GeneCounts --readFilesCommand zcat \
    #        --outSAMtype BAM SortedByCoordinate --outReadsUnmapped Fastx --outFileNamePrefix Default_mapping_s1

    # 2nd mapping (Adjusted options for loose mapping)  
     # $ STAR --genomeDir /out/dir/ALL_index/ --readFilesIn Default_mapping_s1Unmapped.out.mate1 Default_mapping_s1Unmapped.out.mate2  --quantMode GeneCounts \
     #        --outSAMtype BAM SortedByCoordinate  --outFilterMatchNminOverLread 0.4 --outFilterScoreMinOverLread 0.4 --outFilterMultimapNmax 20 \
     #        --outFileNamePrefix Remapped_s1



## MAIN FIGURE ##
 # LOAD necessary R-packages
 library(ggplot2)
 library(LPEseq)
 library(gridExtra)
 library("AnnotationDbi")
 library("org.Hs.eg.db")
 library(EnsDb.Hsapiens.v86)
 library("ggvenn")
 library(VennDiagram)
 library(RColorBrewer)
 library(biomaRt)


 # Figure 2. Mapping performance of standard method and proposed method
  # Figure 2  - B (PROPOSED) 
STAR_mappingRes <- read.csv("/Your/dir/supplementary_DATA/PROPOSED_STARmapping_ResProportion.csv")
STAR_res_ggdata <- data.frame(Seq_BID = rep( STAR_mappingRes[,1], 4 ) , 
                              mapping_type= rep(c("Unique_map", "Multiloci_map" , "Unmapped_short" , "Unmapped_other" ),each= length(STAR_mappingRes[,1])), 
                              star_res_ratio=  unlist(c(STAR_mappingRes[,c(2,3,5,6)])) , RIN= rep ( STAR_mappingRes[,8], 4 ) )



STARres_RIN_sortPLOT <- ggplot(STAR_res_ggdata , aes(x =reorder(STAR_res_ggdata [,1], STAR_res_ggdata [,4]), y= STAR_res_ggdata [,3],fill=as.factor(STAR_res_ggdata [,2])) ) + 
  geom_bar(position="fill",stat = "identity")  + #,color='black',width=0.9
  scale_y_continuous(labels = scales::percent) +
  geom_text(aes(label = round( STAR_res_ggdata[,3]*100 ,1), fontface="bold"), position = position_stack(vjust = 0.5), size = 3.3) +
  scale_x_discrete(labels= STAR_res_ggdata[,4]) + 
  labs(title = "Mapping result summary\n(Tool : STAR)") + ylab("Proportion") + xlab("Sort by RIN")  +
  labs(fill="Mapping type %") +
  theme(plot.title = element_text(hjust = 0.5, size=14, face="bold") , 
        axis.text = element_text(face="bold", size=10 ),
        panel.border = element_blank(),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        axis.line = element_line(colour = "black"),
        panel.background = element_rect(fill="white", colour="white") ,
        axis.title.x = element_text( size=12, face="bold"),
        axis.title.y = element_text( size=12, face="bold"),
        legend.title = element_text( size = 11, face="bold.italic"),
        legend.text = element_text( size = 10))  # +scale_fill_manual(values = c("deeppink4", "#9E9AC8", "#DADAEB"))
STARres_RIN_sortPLOT

# Figure 2. Mapping performance of standard method and proposed method
# Figure 2  - D (PROPOSED) 
RNASeQc_res <- read.csv("/Your/dir/supplementary_DATA/PROPOSED_postAlignment-QC_ResProportion.csv")
mapping_rate_ggdata <- data.frame ( value= unlist(RNASeQc_res[,2:6]) , 
                                    category= rep(c("Unmapped", "Exonic", "Intronic", "Intergenic", "Ambiguous"),each=length(RNASeQc_res[,1])),
                                    BID= rep( RNASeQc_res[,1], 5), 
                                    RIN= rep (RNASeQc_res[,7], 5) )  


sort_mapping_ggdata <- mapping_rate_ggdata [order(mapping_rate_ggdata[,4]),]
sort_mapping_ggdata[,3] <- factor(sort_mapping_ggdata [,3], levels= rev(unique(sort_mapping_ggdata[,3])) )




ggplot(sort_mapping_ggdata , aes(x = reorder(sort_mapping_ggdata[,3], sort_mapping_ggdata[,4]), y= value  , fill=as.factor(category)) )+
  geom_bar(position="fill",stat = "identity") + #,color='black',width=0.9
  scale_y_continuous(labels = scales::percent)  +
  scale_x_discrete(labels= sort_mapping_ggdata[seq(1,length(sort_mapping_ggdata[,1]),5),4]) + 
  geom_text(aes(label =round( sort_mapping_ggdata[,1] *100 ,1),fontface="bold"), 
            position = position_stack(vjust = 0.8), size = 3, color="black") +
  labs(title = "Post alignment QC summary\n(Tool : RNASeQC)") + ylab("Normalized Proportion") + xlab("Sorted by RIN")  +
  labs(fill="Mapping details") +
  theme(plot.title = element_text(hjust = 0.5, size=14, face="bold") , 
        axis.text = element_text(face="bold", size=10 ),
        panel.border = element_blank(),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        axis.line = element_line(colour = "black"),
        panel.background = element_rect(fill="white", colour="white") ,
        axis.title.x = element_text( size=12, face="bold"),
        axis.title.y = element_text( size=12, face="bold"),
        legend.title = element_text( size = 11, face="bold.italic"),
        legend.text = element_text( size = 10)) + 
  scale_fill_manual(values = c("lightpink2" , "firebrick3","deepskyblue4"  ,"chartreuse4"  ,"grey65"))

# Figure 3. Mapping bias and rRNA contamination of standard method and proposed method
# Figure 3 - B (PROPOSED)

proposed_QCres <- read.csv("/Your/dir/supplementary_DATA/PROPOSED_rRNA-contamination_3'mapping-bias_prop.csv")
rownames(proposed_QCres) <-proposed_QCres[,1] ;  proposed_QCres <- proposed_QCres[,-1]
RIN <- read.csv(  "/Your/dir/supplementary_DATA/RINinfo_22-Technical-replciated-subjects.csv"  )

proposed_QCres <- data.frame( proposed_QCres , RIN = RIN$RIN[match( rownames(proposed_QCres) , RIN$BID)] )
proposed_3bias_sigma <- sqrt(proposed_QCres$X3bias_std^2/nrow(proposed_QCres))
proposed_3bias_95CI <- data.frame( low_CI = proposed_QCres$X3bias_mean - 1.96*proposed_3bias_sigma, high_CI = proposed_QCres$X3bias_mean + 1.96*proposed_3bias_sigma )

proposed_QCres_ggdata <- data.frame( rate = c(proposed_QCres$rRNA_rate, proposed_QCres$X3bias_mean  )   ,
                                     group = rep( c("rRNA","3'bias_mean") ,  each=22)  ,
                                     BID = rep(rownames(proposed_QCres),2) , 
                                     RIN = rep(proposed_QCres$RIN,2) ,
                                     low_CI = c( rep(0,22) , proposed_3bias_95CI$low_CI) ,
                                     high_CI = c( rep(0,22) , proposed_3bias_95CI$high_CI))

proposed_QCres_ggdata <- proposed_QCres_ggdata[order(proposed_QCres_ggdata$RIN),]  
proposed_QCres_ggdata$BID <- factor(proposed_QCres_ggdata$BID , levels = rev(unique(proposed_QCres_ggdata$BID))) 

ggplot(data = proposed_QCres_ggdata, aes(x=reorder(proposed_QCres_ggdata$BID, proposed_QCres_ggdata$RIN),y=rate, col= group ,group=group))  +
  geom_line(aes(linetype = group), size=1.5)+
  geom_point(size=3) +
  geom_hline(yintercept=0.5, col = "black",  size=0.5 , linetype="dashed") + 
  geom_hline(yintercept=mean(proposed_QCres_ggdata$rate[which( proposed_QCres_ggdata$group == "3'bias_mean" ) ]), col = "red", size=1) + 
  #  geom_hline(yintercept=mean(proposed_QCres_ggdata$rate[which( proposed_QCres_ggdata$group == "rRNA" ) ]), col = "darkgreen", size=1) + 
  coord_cartesian(ylim =c(0,0.7) )+
  scale_y_continuous(breaks =  seq(0,0.7,0.1 ), labels =seq(0,0.7,0.1 ))+
  geom_errorbar(aes(ymin=low_CI, ymax=high_CI), width=.5 )+
  scale_color_brewer(palette="Dark2")+
  scale_x_discrete(labels= proposed_QCres_ggdata[seq(1,length(proposed_QCres_ggdata[,1]),2),4]) + 
  theme_bw() +
  labs(title = "Proposed") + ylab("Rate") + xlab("Sorted by RIN")  +
  labs(lilnetype="Mapping details") +
  theme(plot.title = element_text(hjust = 0.5, size=14, face="bold") , 
        axis.text = element_text(face="bold", size=10 ),
        panel.border = element_blank(),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        axis.line = element_line(colour = "black"),
        panel.background = element_rect(fill="white", colour="white") ,
        axis.title.x = element_text( size=12, face="bold"),
        axis.title.y = element_text( size=12, face="bold"),
        legend.title = element_text( size = 11, face="bold.italic"),
        legend.text = element_text( size = 10)) 


# Figure 4. Expression profiling 
# Figure 4 - B (PROPOSED)

proposed_genecount <- read.csv( "/Your/dir/supplementary_DATA/PROPOSED_Combined_GeneCounts.csv" )           
RIN <- read.csv(  "/Your/dir/supplementary_DATA/RINinfo_22-Technical-replciated-subjects.csv"  )

norm_genecount <- LPEseq.normalise( proposed_genecount[,2:23] )
# zero removed
normFiltered_genecount  <- LPEseq.normalise( proposed_genecount[ which( apply( proposed_genecount[,2:23], 1 , sum) > 0),2:23] )
PCres <- prcomp(normFiltered_genecount)
# Screening plot (Elbow plot for component screeing)
pcVar.prop  <- (( PCres$sdev^2) / (sum( PCres$sdev^2)))*100  
barplot(  pcVar.prop , ylim=c(0,100),  main="Scree plot" , xlab=paste("Principal component (PC), 1-", length(pcVar.prop)), ylab="Proportion of variation(%)")

PC_ggplotData <- data.frame( BID= colnames(normFiltered_genecount) ,
                             RIN= RIN[match(colnames(normFiltered_genecount) ,RIN$BID),2] ,
                             TechRep_group= as.factor(rep(c(1:11), each=2)), 
                             PC1= PCres$rotation[,1],
                             PC2= PCres$rotation[,2] )

ggplot(PC_ggplotData, aes(x=PC1 , y=PC2, shape=TechRep_group, color=RIN )) +
  geom_point(size=4, alpha=1) +
  scale_shape_manual(values =  65:75 )  +
  coord_cartesian(xlim=c(-0.3,-0.1) , ylim =c(-0.8,0.8)  ) +   # default/loose : xlim = c(0.05,0.3), ylim = c(-0.15,0.55) 
  guides(shape="none") +
  scale_color_gradient(low="blue", high="red") +
  labs(title = "PCA plot") + ylab(paste("PC2(" , round(pcVar.prop[2],1), "%)" ) ) + xlab( paste("PC1(" , round(pcVar.prop[1],1), "%)" ) )  +  
  theme(plot.title = element_text(hjust = 0.5, size=14, face="bold") , 
        axis.text = element_text(face="bold", size=10 ),
        panel.border = element_blank(),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        axis.line = element_line(colour = "black"),
        panel.background = element_rect(fill="white", colour="white") ,
        axis.title.x = element_text( size=12, face="bold"),
        axis.title.y = element_text( size=12, face="bold"),
        legend.title = element_text( size = 11, face="bold.italic"),
        legend.text = element_text( size = 10))
# Figure  4 - D (PROPOSED)


low_exp_list <- c('SPARCL1', 'APOD', 'COL6A1', 'NDRG2', 'CPE', 'CKB' ,'CAMK2N1', 'UCHL1', 'IGFBP5','CRYAB', 'APOE')
hk_exp_list <- c("C1orf43","CHMP2A","EMC7", "GPI","PSMB2" , "PSMB4", "RAB7A", "REEP5", "SNRPD3", "VCP", "VPS29")

low_ENSG_list <-  mapIds(org.Hs.eg.db,keys=low_exp_list, column="ENSEMBL",keytype="SYMBOL",multiVals="first")
hk_ENSG_list <-  mapIds(org.Hs.eg.db,keys=hk_exp_list, column="ENSEMBL",keytype="SYMBOL",multiVals="first")

proposed_genecount <- read.csv( "/Your/dir/supplementary_DATA/PROPOSED_Combined_GeneCounts.csv" )           
RIN <- read.csv(  "/Your/dir/supplementary_DATA/RINinfo_22-Technical-replciated-subjects.csv"  )
norm_genecount <- LPEseq.normalise( proposed_genecount[,2:23] ) ; rownames(norm_genecount) <- proposed_genecount[,1]

low_gene_data <- t(norm_genecount [unlist(lapply(low_ENSG_list , function(x){grep(x, rownames(norm_genecount) )})),])
low_gene_data_2 <- low_gene_data

low_gene_upper_criteria <-  fivenum(as.vector(low_gene_data ))[4] + (fivenum(as.vector(low_gene_data ))[4]-fivenum(as.vector(low_gene_data ))[2])*1.5
low_gene_lower_criteria <- fivenum(as.vector(low_gene_data ))[2] - (fivenum(as.vector(low_gene_data ))[4]-fivenum(as.vector(low_gene_data ))[2])*1.5
low_tmp <- apply(low_gene_data , 2, function(x) { which(x < low_gene_lower_criteria | x > low_gene_upper_criteria)} )

for(i in 1:length(low_gene_data[1,])) {
  if(length(unlist(low_tmp[i])) > 0){
    low_gene_data_2[unlist(low_tmp[i]),i] <- NA 
  }
}

hk_gene_data <- t(norm_genecount[unlist(lapply(hk_ENSG_list , function(x){grep( x, rownames(norm_genecount) )})),]) 
hk_gene_data_2 <- hk_gene_data

hk_gene_upper_criteria <-  fivenum(as.vector(hk_gene_data ))[4] + (fivenum(as.vector(hk_gene_data ))[4]-fivenum(as.vector(hk_gene_data ))[2])*1.5
hk_gene_lower_criteria <- fivenum(as.vector(hk_gene_data ))[2] - (fivenum(as.vector(hk_gene_data ))[4]-fivenum(as.vector(hk_gene_data ))[2])*1.5
hk_tmp <- apply(hk_gene_data , 2, function(x) { which(x < hk_gene_lower_criteria | x > hk_gene_upper_criteria)} )

for(i in 1:length(hk_gene_data[1,])) {
  if(length(unlist(hk_tmp[i])) > 0){
    hk_gene_data_2[unlist(hk_tmp[i]),i] <- NA 
  }
}


tmp_exp_data <- data.frame(low_gene_data[,1:length(low_gene_data[1,])], hk_gene_data[,1:length(hk_gene_data[1,])] )
gg_exp <- c() ; for (i in 1:length(tmp_exp_data[1,])) {gg_exp <- c( gg_exp , tmp_exp_data[,i]) }
gg_exp_data <- data.frame(BID=rep(  rownames(low_gene_data), length(low_exp_list)+length(hk_exp_list)),
                          Exp=gg_exp,
                          categorical_gene= as.factor(rep(c("Low","HK"),c(length(rownames(low_gene_data))*length(low_exp_list),
                                                                          length(rownames(low_gene_data))*length(hk_exp_list))) ),
                          Gene=as.factor(rep(c(low_exp_list,hk_exp_list),each=length(rownames(low_gene_data)))),
                          RIN=rep( RIN[match(rownames(low_gene_data), RIN[,1]),2] ,length(low_exp_list)+length(hk_exp_list)), 
                          categorical_RIN=as.factor(rep(floor(RIN[match(rownames(low_gene_data), RIN[,1]),2]),
                                                        length(low_exp_list)+length(hk_exp_list))) )



low_gene_axis <- data.frame( x= c(4,5,6,7,7.6), 
                             y= c( tapply((gg_exp_data$Exp[which( gg_exp_data$categorical_gene == "Low" & !is.na(gg_exp_data$Exp) )]),
                                          gg_exp_data$categorical_RIN[which(gg_exp_data$categorical_gene == "Low"& !is.na(gg_exp_data$Exp) )] , mean )  ,
                                   
                                   tapply(gg_exp_data$Exp[which(gg_exp_data$categorical_gene == "Low" & gg_exp_data$RIN ==7.6 & !is.na(gg_exp_data$Exp))], 
                                          gg_exp_data$categorical_RIN[which(gg_exp_data$categorical_gene == "Low"& gg_exp_data$RIN ==7.6 & !is.na(gg_exp_data$Exp))] , mean )[4]  ) )

hk_gene_axis <-  data.frame(  x= c(4,5,6,7,7.6), 
                              y= c(tapply(gg_exp_data$Exp[which(gg_exp_data$categorical_gene == "HK"& !is.na(gg_exp_data$Exp))],
                                          gg_exp_data$categorical_RIN[which(gg_exp_data$categorical_gene == "HK"& !is.na(gg_exp_data$Exp))] , mean )  ,
                                   
                                   tapply(gg_exp_data$Exp[which(gg_exp_data$categorical_gene == "HK" & gg_exp_data$RIN == 7.6& !is.na(gg_exp_data$Exp))], 
                                          gg_exp_data$categorical_RIN[which(gg_exp_data$categorical_gene == "HK"& gg_exp_data$RIN == 7.6 & !is.na(gg_exp_data$Exp))] , mean )[4]  ) )

## PLOT 3  - 95% Confidence Intercal(-1.96, 1.96) / 90% (-1.65,1.65) / 99%(-2.56.2.56)  ##

#png("D:/jw_research/GARD_RNA-seq/Technical replication/paper/Result_plot(Main figure+Supplementary )/230707/plot/AAP_GenesExpression.png", width=1800, height=1800, res=400  )

plot(gg_exp_data$Exp ~ gg_exp_data$RIN, pch=19, main=NULL, xlab="RIN" , ylab="Normalized expression",
     col=alpha(c("rosybrown1", "lightsteelblue3")[factor(gg_exp_data$categorical_gene)],0.2),
     cex=1.2, axes=F,  cex.lab=1.2, cex.axis=1.2, ylim=c(0,max(gg_exp_data$Exp, na.rm = T)) )

axis(side=1,at=seq(4,8,by=1),cex.axis = 1.5,font = 1, family = 'serif')
axis(side=2,at=seq(0,max(gg_exp_data$Exp, na.rm = T),by= round(max(gg_exp_data$Exp, na.rm = T)/10,0) ),cex.axis = 1.5,font = 1, family = 'serif')
abline(h=mean(low_gene_axis[,2]), lwd=3, lty=3, col="dodgerblue3")
abline(h=mean(hk_gene_axis[,2]), lwd=3, lty=3, col="lightcoral")

for(i in 1:length(levels(gg_exp_data$categorical_RIN ))) {
  Low_n <- length( gg_exp_data[which(gg_exp_data$categorical_gene=="Low" & gg_exp_data$categorical_RIN == levels(gg_exp_data$categorical_RIN)[i] ),2])
  Low_mean <- mean(gg_exp_data[which(gg_exp_data$categorical_gene=="Low" & gg_exp_data$categorical_RIN == levels(gg_exp_data$categorical_RIN)[i] ),2], na.rm =T)
  Low_sd <- sd(gg_exp_data[which(gg_exp_data$categorical_gene=="Low" & gg_exp_data$categorical_RIN == levels(gg_exp_data$categorical_RIN)[i] ),2], na.rm =T)
  Low_sigma <- sqrt(Low_sd^2/Low_n )
  Low_interval_95 <- Low_mean + c(-1.96, 1.96) * Low_sigma
  arrows(as.numeric( levels(gg_exp_data$categorical_RIN )[i]), Low_interval_95[1] ,
         as.numeric(levels(gg_exp_data$categorical_RIN )[i] ), Low_interval_95[2],  angle=90, col= "mediumblue", code=3, lwd=1.5, length=0.05 ) 
  
  HK_n <- length(gg_exp_data[which(gg_exp_data$categorical_gene=="HK" & gg_exp_data$categorical_RIN == levels(gg_exp_data$categorical_RIN)[i] ),2])
  HK_mean <- mean(gg_exp_data[which(gg_exp_data$categorical_gene=="HK" & gg_exp_data$categorical_RIN == levels(gg_exp_data$categorical_RIN)[i] ),2], na.rm =T)
  HK_sd <- sd(gg_exp_data[which(gg_exp_data$categorical_gene=="HK" & gg_exp_data$categorical_RIN == levels(gg_exp_data$categorical_RIN)[i] ),2], na.rm =T)
  HK_sigma <- sqrt(HK_sd^2/HK_n )
  HK_interval_95 <- HK_mean + c(-1.96, 1.96) * HK_sigma
  arrows(as.numeric( levels(gg_exp_data$categorical_RIN )[i]), HK_interval_95[1] ,
         as.numeric(levels(gg_exp_data$categorical_RIN )[i] ), HK_interval_95[2],  angle=90,col= "red3", code=3, lwd=1.5, length=0.05 ) 
  
  points(as.numeric(levels(gg_exp_data$categorical_RIN )[i] ), Low_mean , pch=16, cex=1, col= "mediumblue") 
  points(as.numeric(levels(gg_exp_data$categorical_RIN )[i] ), HK_mean , pch=16, cex=1, col= "red3") 
} ;legend("topright",legend = c("house-keeping genes" , "blood-silent genes"), pch = 19, col = c("rosybrown1", "lightsteelblue3") ,bg="transparent" , box.lty = 0 )


# Figure 5. FDR control
# Figure 5 - B (STANDARD)
proposed_genecount <- read.csv( "/Your/dir/supplementary_DATA/PROPOSED_Combined_GeneCounts.csv" )           
RIN <- read.csv(  "/Your/dir/supplementary_DATA/RINinfo_22-Technical-replciated-subjects.csv"  )
RIN <- RIN[match( colnames(norm_genecount) , RIN$BID ),]
RIN_diff <- abs ( RIN[seq(1,length(RIN[,1]),2),2] - RIN[seq(2,length(RIN[,1]),2),2]  )


norm_genecount <- LPEseq.normalise( proposed_genecount[which(apply(proposed_genecount[,2:23] ,1, sum) > 0),2:23] )
norm_genecount <- LPEseq.normalise( proposed_genecount[,2:23] )





DEtestRes <- matrix(NA,3,ncol(norm_genecount))
for (i in seq( 1, ncol(norm_genecount), 2) ) { 
  LPEseq.qvalue <- LPEseq.test(norm_genecount[,i] , norm_genecount[,i+1], d=0.89)$q.value 
  DEtestRes[1,i] <- length(which( LPEseq.qvalue < 0.01) )
  DEtestRes[2,i] <- length(which( LPEseq.qvalue < 0.05) )
  DEtestRes[3,i] <- length(which( LPEseq.qvalue < 0.1) )
  print(i)}  ; DEtestRes <- DEtestRes[,c(seq( 1, ncol(norm_genecount), 2))]  ;  rownames(DEtestRes) <- paste("q-val", c(0.01,0.05,0.1),sep="")

LPEres_gg_ALLdiff <- data.frame ( Num.DEG = c( DEtestRes[1,], DEtestRes[2,], DEtestRes[3,]), q.val= as.factor(rep(c(0.01 , 0.05, 0.1), each=11)) , RIN_Diff= rep( RIN_diff,3) )
LPEres_ggdata <- data.frame(LPEres_gg_ALLdiff   ,  line = rep(c( "solid", "dotted", "solid") ,each=11) )  
LPEres_ggdata_outlierX <- LPEres_gg_ALLdiff[which(LPEres_gg_ALLdiff[,3] < 2.5 ),]

ggplot(LPEres_ggdata , aes(x=RIN_Diff , y=as.numeric(Num.DEG/nrow(norm_genecount)*100), shape=q.val, color=q.val, fill=q.val)) +
  coord_cartesian(ylim = c(0,20), xlim = c(0, 3.3)) +  
  geom_point(size=4, alpha=0.3) +
  scale_color_manual(values = c("grey88", "brown1", "grey"))+
  scale_fill_manual(values = c("brown1", "gold1", "steelblue2") )+
  scale_x_continuous(breaks = seq(from = 0, to = 3, by = 0.5))+
  scale_y_continuous(breaks = seq(from = 0, to = 20, by = 5), labels= c(paste( seq(0,20,5), "%" , sep="") ) ) +
  
  #geom_hline(yintercept = 30, linetype = 3, col = 'grey70', size = 2) +
  labs(fill="q-value" , colour="q-value", shape="q-value" )+
  geom_smooth(method=lm, se=F , size=1.5, aes(linetype = line), show.legend = FALSE) +
  theme(plot.title = element_text(hjust = 0.5, size=14, face="bold") , 
        axis.text = element_text(face="bold", size=10 ),
        panel.border = element_blank(),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        axis.line = element_line(colour = "black"),
        panel.background = element_rect(fill="white", colour="white") ,
        axis.title.x = element_text( size=12, face="bold"),
        axis.title.y = element_text( size=12, face="bold"),
        legend.key=element_rect(fill='white'),  
        legend.title = element_text( size = 11, face="bold.italic"),
        legend.text = element_text( size = 10)) + 
  ylab("False discovery rate") + xlab("��RIN of technical replication")  

