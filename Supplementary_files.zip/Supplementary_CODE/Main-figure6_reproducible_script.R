# Title : Unlocking the Potential of Low Quality Total RNA-seq Data: A Stepwise Mapping Approach for Improved Quantitative Analyses
# Authors : Jiwoon Lee and JungSoo Gim* (This script was written by Jiwoon Lee ! (jiun.t.ger@gmail.com))
# 

## MAIN FIGURE ##
 # LOAD packages
 library(ggplot2)

 library(gridExtra)
 library("AnnotationDbi")
 library("org.Hs.eg.db")
 library(EnsDb.Hsapiens.v86)
 library("ggvenn")
 library(VennDiagram)
 library(RColorBrewer)
 library(biomaRt)
 
 # Figure 6. Biotype : Proposed ??? Control(+)

standard <- read.table("/Your/dir/supplementary_DATA/PPD(48986)_ENSGID.txt", fill=T)[,1]
standard <- unique(substr(standard, 1,15))

proposed <- read.table("/Your/dir/supplementary_DATA/AAP(49950)_ENSGID.txt", fill=T)[,1]
proposed <- unique(substr(proposed, 1,15))

pos_control <- read.table("/Your/dir/supplementary_DATA/PPP(50112)_ENSGID.txt", fill=T)[,1]
pos_control <- unique(substr(pos_control, 1,15))

 # Figure 6. Biotype : Proposed ??? Control(+)
 # Figure 6 - Venndiagram (PROPOSED VS CONTROL(+))


# vendiagram
setwd("D:/jw_research/GARD_RNA-seq/Technical replication/paper/Result_scripts/")
myCol <- brewer.pal(3, "Pastel2")[1:3]

venn.diagram( x = list( standard, proposed ,pos_control),
              category.names = c( "Standard", "Proposed", "Control(+)"),
              filename = "test_venn.png" ,
              output =T ,

              
              # Output features
              imagetype="png" ,
              height = 800 , 
              width = 800 , 
              resolution = 300,
              compression = "lzw",
              
              # Circles
              lwd = 2,
              lty = 'blank',
              fill = myCol,
              
              # Numbers
              cex = .6,
              fontface = "bold",
              fontfamily = "sans",
              
              # Set names
              cat.cex = 0.6,
              cat.fontface = "bold",
              cat.default.pos = "outer",
              cat.pos = c(-27,27,135),
              cat.dist = c(0.055, 0.055 , 0.085),
              cat.fontfamily = "sans",
              rotation = 1
              )

# Figure 6. Biotype : Proposed ??? Control(+)
# Figure 6 - BARPLOT

PPP_AAP_onlyPPP_1645 <- ensembldb::select(EnsDb.Hsapiens.v86, keys= setdiff(pos_control, proposed) , keytype = "GENEID", columns = c("SYMBOL","GENEID", "GENEBIOTYPE"))
PPP_AAP_onlyAAP_1483 <- ensembldb::select(EnsDb.Hsapiens.v86, keys= setdiff( proposed, pos_control) , keytype = "GENEID", columns = c("SYMBOL","GENEID", "GENEBIOTYPE"))

# data pre-processing - PPP vs AAP >> only PPP

PPP_AAP_onlyPPP_1645[c( grep("_gene|TR",PPP_AAP_onlyPPP_1645[,3])) ,4] <- "Immune gene"
PPP_AAP_onlyPPP_1645[c( grep("pseudogene",PPP_AAP_onlyPPP_1645[,3])) ,4] <- "Pseudogene"
PPP_AAP_onlyPPP_1645[c( grep("TEC",PPP_AAP_onlyPPP_1645[,3])) ,4] <- "TEC"
PPP_AAP_onlyPPP_1645[c( which( PPP_AAP_onlyPPP_1645[,3] == "miRNA" | PPP_AAP_onlyPPP_1645[,3] == "misc_RNA" |  PPP_AAP_onlyPPP_1645[,3] == "rRNA" |
                                 PPP_AAP_onlyPPP_1645[,3] == "snoRNA" | PPP_AAP_onlyPPP_1645[,3] == "sRNA" | PPP_AAP_onlyPPP_1645[,3] == "snRNA"  ) )  ,4] <- "ncRNA"
PPP_AAP_onlyPPP_1645[ which(PPP_AAP_onlyPPP_1645[,3] == "protein_coding" ) ,4 ] <- "Protein coding"
PPP_AAP_onlyPPP_1645[  which( is.na(PPP_AAP_onlyPPP_1645[ ,4] ) == T ), 4 ] <-  "lncRNA"
PPP_AAP_onlyPPP_data <- data.frame ( group = rep("PPP" , 7) ,
                                     biotype = c( names( table(PPP_AAP_onlyPPP_1645[ ,4])), "Unknown" )  , 
                                     count= c( as.vector( table(PPP_AAP_onlyPPP_1645[ ,4])),  1645-1570  ) ,
                                     ratio = round( c( as.vector( table(PPP_AAP_onlyPPP_1645[ ,4])), 1645-1570) /1645*100 , 1 ) )


# data preprocessing - PPP vs AAP >> only AAP
PPP_AAP_onlyAAP_1483 [c( grep("_gene|TR",PPP_AAP_onlyAAP_1483 [,3])) ,4] <- "Immune gene"
PPP_AAP_onlyAAP_1483 [c( grep("pseudogene",PPP_AAP_onlyAAP_1483 [,3])) ,4] <- "Pseudogene"
PPP_AAP_onlyAAP_1483 [c( grep("TEC",PPP_AAP_onlyAAP_1483 [,3])) ,4] <- "TEC"
PPP_AAP_onlyAAP_1483 [c( which( PPP_AAP_onlyAAP_1483 [,3] == "miRNA" | PPP_AAP_onlyAAP_1483 [,3] == "misc_RNA" |  PPP_AAP_onlyAAP_1483 [,3] == "rRNA" |
                                  PPP_AAP_onlyAAP_1483 [,3] == "snoRNA" | PPP_AAP_onlyAAP_1483 [,3] == "sRNA" | PPP_AAP_onlyAAP_1483 [,3] == "snRNA"  ) )  ,4] <- "ncRNA"
PPP_AAP_onlyAAP_1483 [ which(PPP_AAP_onlyAAP_1483 [,3] == "protein_coding" ) ,4 ] <- "Protein coding"
PPP_AAP_onlyAAP_1483 [  which( is.na( PPP_AAP_onlyAAP_1483 [ ,4] ) == T ), 4 ] <-  "lncRNA"


PPP_AAP_onlyAAP_data <- data.frame ( group = rep("AAP" , 7) ,
                                     biotype = c( names( table(PPP_AAP_onlyAAP_1483 [ ,4]) ), "Unknown" )  , 
                                     count= c( as.vector( table(PPP_AAP_onlyAAP_1483 [ ,4])), 1483-1287 ) ,
                                     ratio = round( c( as.vector( table(PPP_AAP_onlyAAP_1483 [ ,4])),1483-1287 )/1483*100 , 1 ) )





# BAR PLOT (PPP vs AAP)   
ppp_AAP_ggdata <- rbind(PPP_AAP_onlyAAP_data , PPP_AAP_onlyPPP_data)


ggplot(ppp_AAP_ggdata , aes(x= group , y=count , fill=biotype)) + 
  geom_bar(stat = "identity") +
  labs(title = "Biotype Comparison") + ylab("Count") + xlab( "Group")  +
  labs(fill="Biotype") +
  theme(plot.title = element_text(hjust = 0.5, size=14, face="bold") , 
        axis.text = element_text(face="bold", size=13 ),
        panel.border = element_blank(),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        axis.line = element_line(colour = "black"),
        panel.background = element_rect(fill="white", colour="white") ,
        axis.title.x = element_text( size=15, face="bold"),
        axis.title.y = element_text( size=15, face="bold"),
        legend.title = element_text( size = 11, face="bold.italic"),
        legend.text = element_text( size = 10)) +
  scale_y_continuous(breaks =  c(  seq(0,1000, 500), 1483,1645 ) )  + 
  geom_text( aes(label = paste( ratio, "%" )  , fontface="bold"), 
             position = position_stack(vjust = 0.5), size = 4.5, color="black") 

